package me.kiras.aimwhere.libraries.slick.command;

/**
 * Marker class for abstract input controls
 * 
 * @author joverton
 */
public interface Control {
}
