package me.kiras.aimwhere.customskinloader.profile;

class CachedProfile {

   public UserProfile profile;
   public long expiryTime = 0L;
   public boolean loading = false;


}
