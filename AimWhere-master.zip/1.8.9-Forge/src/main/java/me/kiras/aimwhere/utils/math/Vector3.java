package me.kiras.aimwhere.utils.math;

public class Vector3<T extends Number> extends Vector<Number>
{
    public Vector3(final T x, final T y, final T z) {
        super(x, y, z);
    }
}
