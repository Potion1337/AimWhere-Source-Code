package me.kiras.aimwhere.utils.other

class MessageBase(val message : String) {
    var index = 0
    var nextIndex = 0
    var notThis = false
}